import './bootstrap';
import '../css/app.css';
import 'flowbite';
import './datatables';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();
